# RegressionExplorer
Shiny App to play around with the impact of different variables on a linear regression
